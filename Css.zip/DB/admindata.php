<?php
function createConnObj() {
   $conn = mysqli_connect("localhost", "root", "", "admin");

   if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
   }

   return $conn;
}

function insertAdmin($conn, $fullname, $email, $username, $password, $photo,$gender) {
   $sql = "INSERT INTO register (fullname, email, username, password, photo,gender)
           VALUES ('$fullname', '$email', '$username', '$password', '$photo', '$gender')";

    

   if (mysqli_query($conn, $sql)) {
       echo "Data inserted successfully!";
   } else {
       echo "Error: " . mysqli_error($conn);
   }
}

function selectAdmin($conn, $id) {
    $sql = "SELECT * FROM register WHERE id='$id'";
    return mysqli_query($conn, $sql);
}

function closeConn($conn) {
   mysqli_close($conn);
}
?>